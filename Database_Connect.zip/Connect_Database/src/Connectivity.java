import java.sql.Connection;
import java.sql.DriverManager;

import static java.lang.Class.forName;

public class Connectivity{
    public static void main(String [] args)
    {
        try{
            //device for MySQL & Java
            Class.forName("com.mysql.cj.jdbc.Driver");
            //establish connection between mysql & local system
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/conn", "root", "1234");
            if(con!=null)
            {
                System.out.println("Connected to the MySQL Server");
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}