import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class CreateTable {
    public static void main(String[] args) {
        try {
            // Load the MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish a connection to the database
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbdemo1", "root", "1234");

            // Check if the connection is successful
            if (con != null) {
                System.out.println("Connected to the database");
            } else {
                System.out.println("Not connected to the database");
            }

            // Create a statement object
            Statement stmt = con.createStatement();

            // Write the SQL query to create the table
            String createTableSQL = "Create table InfoTable (username varchar(20), password int);";

            // Execute the SQL statement
            stmt.executeUpdate(createTableSQL);
            System.out.println("Table created successfully");

            // Close the connection
            con.close();
        } catch (Exception e) {
            // Print any exceptions that occur
            System.out.println(e);
        }
    }
}