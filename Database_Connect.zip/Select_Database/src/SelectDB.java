import java.sql.Connection;
import java.sql.DriverManager;
public class SelectDB {
    public static void main(String [] args){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            //provide dbname to the can object
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/dbdemo1", "root", "1234");
            if(con!=null)
            {
                System.out.println("Connected to database");
            }
            else{
                System.out.println("Not connected to database");
            }
            con.close();
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}