import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
public class CreateDB {
    public static void main(String [] args){
        try{
            //driver for MySQL & Java
            Class.forName("com.mysql.cj.jdbc.Driver");
            //establish connection between MySQL & local system
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/conn", "root", "1234");
            //statement class is used to execute MySQL queries
            Statement stmt = con.createStatement();
            //query for database creation
            stmt.executeUpdate("Create Database dbDemo1");
            if(con!=null)
            {
                System.out.println("Connected to the SQL Server & Created databases");
            }
            con.close(); //connection close
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}