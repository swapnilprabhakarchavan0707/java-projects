package com.sunbeam;

public interface UserDao {
    User findByEmail(String email);
}