package com.sunbeam;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    private static final Logger logger = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    private UserDao userDao;

    @GetMapping("/login")
    public String showLoginPage() {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam("email") String email, @RequestParam("password") String password, Model model) {
        try {
            User user = userDao.findByEmail(email);
            if (user != null && user.getPassword().equals(password)) {
                model.addAttribute("message", "Welcome, " + user.getName());
                return "welcome";
            } else {
                model.addAttribute("message", "Login Failed");
                return "login";
            }
        } catch (Exception e) {
            logger.error("An error occurred during login", e);
            model.addAttribute("message", "An error occurred");
            return "login";
        }
    }
}