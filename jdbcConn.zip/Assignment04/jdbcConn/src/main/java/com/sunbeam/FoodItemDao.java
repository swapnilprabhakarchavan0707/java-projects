package com.sunbeam;

import java.util.List;

public interface FoodItemDao {
    FoodItem findByName(String name) throws Exception;
    FoodItem findById(int id) throws Exception;
    List<FoodItem> findAll() throws Exception;
    int save(FoodItem item) throws Exception;
    int updatePrice(int id, double newPrice) throws Exception;
    int deleteById(int id) throws Exception;
}
