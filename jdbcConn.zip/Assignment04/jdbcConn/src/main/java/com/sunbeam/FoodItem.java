package com.sunbeam;

public class FoodItem {
    private int fid;
    private String name;
    private double price;
    private String description;
    private String image;

    // Default constructor
    public FoodItem() {
    }

    // Constructor with all fields
    public FoodItem(int fid, String name, double price, String description, String image) {
        this.fid = fid;
        this.name = name;
        this.price = price;
        this.description = description;
        this.image = image;
    }

    // Constructor without fid (for insertion)
    public FoodItem(String name, double price, String description, String image) {
        this.name = name;
        this.price = price;
        this.description = description;
        this.image = image;
    }

    // Getters and Setters
    public int getFid() {
        return fid;
    }

    public void setFid(int fid) {
        this.fid = fid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "FoodItem{" +
                "fid=" + fid +
                ", name='" + name + '\'' +
                ", price=" + price +
                ", description='" + description + '\'' +
                ", image='" + image + '\'' +
                '}';
    }
}
