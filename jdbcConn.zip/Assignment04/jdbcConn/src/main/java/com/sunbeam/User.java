package com.sunbeam;

public class User {
    private int uid;
    private String name;
    private String email;
    private String password;
    private String mobile;

    // Default constructor
    public User() {
    }

    // Constructor with all fields
    public User(int uid, String name, String email, String password, String mobile) {
        this.uid = uid;
        this.name = name;
        this.email = email;
        this.password = password;
        this.mobile = mobile;
    }

    // Constructor without uid (for insertion)
    public User(String name, String email, String password, String mobile) {
        this.name = name;
        this.email = email;
        this.password = password;
        this.mobile = mobile;
    }

    // Getters and Setters
    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    @Override
    public String toString() {
        return "User{" +
                "uid=" + uid +
                ", name='" + name + '\'' +
                ", email='" + email + '\'' +
                ", mobile='" + mobile + '\'' +
                '}';
    }
}
