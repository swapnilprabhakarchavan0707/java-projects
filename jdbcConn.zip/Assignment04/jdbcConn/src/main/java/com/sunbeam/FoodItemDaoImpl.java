package com.sunbeam;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FoodItemDaoImpl implements FoodItemDao, AutoCloseable {
    private Connection conn;

    public FoodItemDaoImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public FoodItem findByName(String name) throws Exception {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be null or empty");
        }

        String sql = "SELECT * FROM food WHERE name = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, name);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return extractFoodItemFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            throw new Exception("Error finding food item by name", e);
        }
        return null;
    }

    @Override
    public FoodItem findById(int id) throws Exception {
        String sql = "SELECT * FROM food WHERE fid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return extractFoodItemFromResultSet(rs);
                }
            }
        } catch (SQLException e) {
            throw new Exception("Error finding food item by id", e);
        }
        return null;
    }

    @Override
    public List<FoodItem> findAll() throws Exception {
        List<FoodItem> items = new ArrayList<>();
        String sql = "SELECT * FROM food";
        try (Statement st = conn.createStatement(); ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                items.add(extractFoodItemFromResultSet(rs));
            }
        } catch (SQLException e) {
            throw new Exception("Error finding all food items", e);
        }
        return items;
    }

    @Override
    public int save(FoodItem item) throws Exception {
        if (item == null) {
            throw new IllegalArgumentException("Food item cannot be null");
        }

        String sql = "INSERT INTO food(name, price, description, image) VALUES (?, ?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setString(1, item.getName());
            pst.setDouble(2, item.getPrice());
            pst.setString(3, item.getDescription());
            pst.setString(4, item.getImage());
            int rowsAffected = pst.executeUpdate();

            if (rowsAffected > 0) {
                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        item.setFid(rs.getInt(1));
                    }
                }
            }

            return rowsAffected;
        } catch (SQLException e) {
            throw new Exception("Error saving food item", e);
        }
    }

    @Override
    public int updatePrice(int id, double newPrice) throws Exception {
        String sql = "UPDATE food SET price = ? WHERE fid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setDouble(1, newPrice);
            pst.setInt(2, id);
            return pst.executeUpdate();
        } catch (SQLException e) {
            throw new Exception("Error updating food price", e);
        }
    }

    @Override
    public int deleteById(int id) throws Exception {
        String sql = "DELETE FROM food WHERE fid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, id);
            return pst.executeUpdate();
        } catch (SQLException e) {
            throw new Exception("Error deleting food item", e);
        }
    }

    private FoodItem extractFoodItemFromResultSet(ResultSet rs) throws SQLException {
        FoodItem item = new FoodItem();
        item.setFid(rs.getInt("fid"));
        item.setName(rs.getString("name"));
        item.setPrice(rs.getDouble("price"));
        item.setDescription(rs.getString("description"));
        item.setImage(rs.getString("image"));
        return item;
    }

    @Override
    public void close() throws Exception {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }
}