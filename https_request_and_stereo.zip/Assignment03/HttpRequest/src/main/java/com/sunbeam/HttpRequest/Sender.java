package com.sunbeam.HttpRequest;

public interface Sender {
    void send(double value);
}
