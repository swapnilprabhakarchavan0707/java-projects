package com.sunbeam.HttpRequest;

import org.springframework.stereotype.Component;

@Component
public class HttpSender implements Sender {
    @Override
    public void send(double value) {
        System.out.println("Sending via HTTP: " + value);
    }
}