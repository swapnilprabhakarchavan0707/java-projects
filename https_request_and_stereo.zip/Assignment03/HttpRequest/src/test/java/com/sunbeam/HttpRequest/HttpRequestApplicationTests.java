package com.sunbeam.HttpRequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpRequestApplicationTests {

	@Test
	void contextLoads() {
	}

}
