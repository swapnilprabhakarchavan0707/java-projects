package com.sunbeam;

import com.bank.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Import;

@SpringBootApplication
//@ComponentScan("com.bank")
@Import(AppConfig.class)
public class StereoannotationApplication implements CommandLineRunner {
    public static void main(String[] args) {
        SpringApplication.run(StereoannotationApplication.class, args);
    }

    @Autowired
    private ApplicationContext ctx;

    @Override
    public void run(String... args) throws Exception {
        Logger logger1 = ctx.getBean(ConsoleLoggerImpl.class);
//        logger1.log("Message 1 -- Hello");
        Logger logger2 = ctx.getBean(FileLoggerImpl.class);
//        logger2.log("Message 3 -- Bye");
        Logger logger = ctx.getBean(Logger.class); // Error: If no bean is @Primary
        // if any one logger is primary, it will accessed.
//        logger.log("Message 4 -- new message");

        Account acc = (Account) ctx.getBean("acc");
        //acc.setLogger(logger1); // ConsoleLoggerImpl attached to Account
        //acc.setLogger(logger2); // FileLoggerImpl attached to Account
        //acc.setLogger(logger); // @Primary logger bean attached to Account
        System.out.println("acc: " + acc);
        acc.deposit(3000.0);
        System.out.println("acc: " + acc);
        acc.withdraw(2000.0);
        System.out.println("acc: " + acc);

        SpELTest test = ctx.getBean(SpELTest.class);
        test.printInfo();
    }
}
