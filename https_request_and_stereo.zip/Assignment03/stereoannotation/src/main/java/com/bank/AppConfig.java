package com.bank;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan
public class AppConfig {
    @Bean
    public Account acc() {
        AccountImpl account = new AccountImpl();
        account.setId(101);
        account.setType("Saving");
        account.setBalance(20000.0);
        return account;
    }
}