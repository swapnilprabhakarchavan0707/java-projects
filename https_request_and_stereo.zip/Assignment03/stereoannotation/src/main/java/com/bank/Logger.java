package com.bank;

public interface Logger {
    void log(String message);
}
