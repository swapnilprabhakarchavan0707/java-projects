package com.bank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

import java.io.FileOutputStream;
import java.io.PrintStream;

@Component("fileLoggerImpl")
public class FileLoggerImpl implements Logger {
    private String logFilePath = "applog.txt";

    @Override
    public void log(String message) {
        System.out.println("File: " + message);
        try (FileOutputStream fout = new FileOutputStream(logFilePath, true);
             PrintStream out = new PrintStream(fout)) {
            out.println(message);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}