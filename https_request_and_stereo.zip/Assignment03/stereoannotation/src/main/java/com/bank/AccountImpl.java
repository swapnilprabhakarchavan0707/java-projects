package com.bank;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class AccountImpl implements Account {
    private int id;
    private String type;
    private double balance;

    @Autowired
    @Qualifier("fileLoggerImpl")
    private Logger logger;

    @Override
    public void deposit(double amount) {
        this.balance = this.balance + amount;
        if(logger != null) {
            String msg = "Account " + this.id + " is credited amount Rs. " + amount;
            logger.log(msg);
        }
    }

    @Override
    public void withdraw(double amount) {
        this.balance = this.balance - amount;
        if(logger != null) {
            String msg = "Account " + this.id + " is debited amount Rs. " + amount;
            logger.log(msg);
        }
    }
}