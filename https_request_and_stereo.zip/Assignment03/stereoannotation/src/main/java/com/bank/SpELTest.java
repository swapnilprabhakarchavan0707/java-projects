package com.bank;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SpELTest {
    @Value("#{acc}")
    private Account acc;
    @Value("#{acc.type}")
    private String accType;
    @Value("#{acc.getBalance()}")
    private double accBalance;

    public void printInfo() {
        System.out.println("SpEL Test: acc="+acc);
        System.out.println("SpEL Test: accType="+accType);
        System.out.println("SpEL Test: accBalance="+accBalance);
    }
}