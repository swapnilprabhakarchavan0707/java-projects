package com.sunbeam.stereoannotation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StereoannotationApplicationTests {

	@Test
	void contextLoads() {
	}

}
