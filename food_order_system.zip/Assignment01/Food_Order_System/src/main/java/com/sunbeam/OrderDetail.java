package com.sunbeam;

public class OrderDetail {
    private int odid;
    private int oid;
    private int fid;
    private int quantity;

    // Default constructor
    public OrderDetail() {
    }

    // Constructor with all fields
    public OrderDetail(int odid, int oid, int fid, int quantity) {
        this.odid = odid;
        this.oid = oid;
        this.fid = fid;
        this.quantity = quantity;
    }

    // Constructor without odid (for insertion)
    public OrderDetail(int oid, int fid, int quantity) {
        this.oid = oid;
        this.fid = fid;
        this.quantity = quantity;
    }

    // Getters and Setters
    public int getOdid() {
        return odid;
    }

    public void setOdid(int odid) {
        this.odid = odid;
    }

    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public int getFid() {
        return fid;
    }

    public void setFid(int fid) {
        this.fid = fid;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    @Override
    public String toString() {
        return "OrderDetail{" +
                "odid=" + odid +
                ", oid=" + oid +
                ", fid=" + fid +
                ", quantity=" + quantity +
                '}';
    }
}