package com.sunbeam;

// FILE: OrderDao.java
// DESCRIPTION: DAO Interface defining all Order-related database operations

import java.util.List;

public interface OrderDao {
    // Methods for Order
    int saveOrder(Order order) throws Exception;
    Order findOrderById(int orderId) throws Exception;
    List<Order> findOrdersByUserId(int userId) throws Exception;
    List<Order> findAllOrders() throws Exception;
    int updateOrderStatus(int orderId, String status) throws Exception;

    // Methods for OrderDetails
    int saveOrderDetail(OrderDetail detail) throws Exception;
    List<OrderDetail> findOrderDetailsByOrderId(int orderId) throws Exception;
}