package com.sunbeam;

// FILE: OrderDaoImpl.java
// DESCRIPTION: Implementation class for OrderDao interface with JDBC code

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class OrderDaoImpl implements OrderDao, AutoCloseable {
    private Connection conn;

    public OrderDaoImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public int saveOrder(Order order) throws Exception {
        String sql = "INSERT INTO orders(uid, total_amount, status) VALUES (?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, order.getUid());
            pst.setDouble(2, order.getTotalAmount());
            pst.setString(3, order.getStatus() != null ? order.getStatus() : "PENDING");

            int rowsAffected = pst.executeUpdate();

            // Get the generated key and return it
            if (rowsAffected > 0) {
                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        int generatedId = rs.getInt(1);
                        order.setOid(generatedId);
                        return generatedId;
                    }
                }
            }

            return 0;
        }
    }

    @Override
    public Order findOrderById(int orderId) throws Exception {
        String sql = "SELECT * FROM orders WHERE oid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, orderId);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    return extractOrderFromResultSet(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Order> findOrdersByUserId(int userId) throws Exception {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders WHERE uid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, userId);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    orders.add(extractOrderFromResultSet(rs));
                }
            }
        }
        return orders;
    }

    @Override
    public List<Order> findAllOrders() throws Exception {
        List<Order> orders = new ArrayList<>();
        String sql = "SELECT * FROM orders";
        try (Statement st = conn.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                orders.add(extractOrderFromResultSet(rs));
            }
        }
        return orders;
    }

    @Override
    public int updateOrderStatus(int orderId, String status) throws Exception {
        String sql = "UPDATE orders SET status = ? WHERE oid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setString(1, status);
            pst.setInt(2, orderId);
            return pst.executeUpdate();
        }
    }

    @Override
    public int saveOrderDetail(OrderDetail detail) throws Exception {
        String sql = "INSERT INTO orderdetails(oid, fid, quantity) VALUES (?, ?, ?)";
        try (PreparedStatement pst = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            pst.setInt(1, detail.getOid());
            pst.setInt(2, detail.getFid());
            pst.setInt(3, detail.getQuantity());

            int rowsAffected = pst.executeUpdate();

            // Get the generated key and set it to the detail object
            if (rowsAffected > 0) {
                try (ResultSet rs = pst.getGeneratedKeys()) {
                    if (rs.next()) {
                        detail.setOdid(rs.getInt(1));
                    }
                }
            }

            return rowsAffected;
        }
    }

    @Override
    public List<OrderDetail> findOrderDetailsByOrderId(int orderId) throws Exception {
        List<OrderDetail> details = new ArrayList<>();
        String sql = "SELECT * FROM orderdetails WHERE oid = ?";
        try (PreparedStatement pst = conn.prepareStatement(sql)) {
            pst.setInt(1, orderId);
            try (ResultSet rs = pst.executeQuery()) {
                while (rs.next()) {
                    details.add(extractOrderDetailFromResultSet(rs));
                }
            }
        }
        return details;
    }

    private Order extractOrderFromResultSet(ResultSet rs) throws SQLException {
        Order order = new Order();
        order.setOid(rs.getInt("oid"));
        order.setUid(rs.getInt("uid"));
        order.setOrderDate(rs.getTimestamp("odate"));
        order.setDeliveryDate(rs.getTimestamp("deldate"));
        order.setTotalAmount(rs.getDouble("total_amount"));
        order.setStatus(rs.getString("status"));
        return order;
    }

    private OrderDetail extractOrderDetailFromResultSet(ResultSet rs) throws SQLException {
        OrderDetail detail = new OrderDetail();
        detail.setOdid(rs.getInt("odid"));
        detail.setOid(rs.getInt("oid"));
        detail.setFid(rs.getInt("fid"));
        detail.setQuantity(rs.getInt("quantity"));
        return detail;
    }

    @Override
    public void close() throws Exception {
        if (conn != null && !conn.isClosed()) {
            conn.close();
        }
    }
}