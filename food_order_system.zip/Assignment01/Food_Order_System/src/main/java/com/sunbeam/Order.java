package com.sunbeam;

import java.sql.Timestamp;
import java.util.List;

public class Order {
    private int oid;
    private int uid;
    private Timestamp orderDate;
    private Timestamp deliveryDate;
    private double totalAmount;
    private String status;
    private List<OrderDetail> orderDetails;

    // Default constructor
    public Order() {
    }

    // Constructor with all fields
    public Order(int oid, int uid, Timestamp orderDate, Timestamp deliveryDate,
                 double totalAmount, String status) {
        this.oid = oid;
        this.uid = uid;
        this.orderDate = orderDate;
        this.deliveryDate = deliveryDate;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // Constructor without oid (for insertion)
    public Order(int uid, double totalAmount, String status) {
        this.uid = uid;
        this.totalAmount = totalAmount;
        this.status = status;
    }

    // Getters and Setters
    public int getOid() {
        return oid;
    }

    public void setOid(int oid) {
        this.oid = oid;
    }

    public int getUid() {
        return uid;
    }

    public void setUid(int uid) {
        this.uid = uid;
    }

    public Timestamp getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Timestamp orderDate) {
        this.orderDate = orderDate;
    }

    public Timestamp getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(Timestamp deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public List<OrderDetail> getOrderDetails() {
        return orderDetails;
    }

    public void setOrderDetails(List<OrderDetail> orderDetails) {
        this.orderDetails = orderDetails;
    }

    @Override
    public String toString() {
        return "Order{" +
                "oid=" + oid +
                ", uid=" + uid +
                ", orderDate=" + orderDate +
                ", deliveryDate=" + deliveryDate +
                ", totalAmount=" + totalAmount +
                ", status='" + status + '\'' +
                '}';
    }
}