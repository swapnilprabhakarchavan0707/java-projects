package com.sunbeam;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/food_order_db";
    private static final String DB_USER = "W3_92581_Swapnil"; // Replace with your MySQL username
    private static final String DB_PASSWORD = "manager"; // Replace with your MySQL password

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Database connection successful!");

            while (true) {
                System.out.println("\n--- Food Order System ---");
                System.out.println("1. Manage Users");
                System.out.println("2. Manage Food Items");
                System.out.println("3. Manage Orders");
                System.out.println("0. Exit");
                System.out.print("Enter your choice: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        manageUsers(scanner);
                        break;
                    case 2:
                        manageFoodItems(scanner);
                        break;
                    case 3:
                        manageOrders(scanner);
                        break;
                    case 0:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid choice. Please try again.");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void manageUsers(Scanner scanner) throws Exception {
        System.out.println("\n--- User Management ---");
        System.out.println("1. Add User");
        System.out.println("2. Find User by Email");
        System.out.println("3. Show All Users");
        System.out.println("4. Delete User by Email");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             UserDaoImpl userDao = new UserDaoImpl(conn)) {

            switch (choice) {
                case 1:
                    // Logic to add a user
                    System.out.print("Enter name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter password: ");
                    String password = scanner.nextLine();
                    System.out.print("Enter mobile: ");
                    String mobile = scanner.nextLine();

                    User newUser = new User();
                    newUser.setName(name);
                    newUser.setEmail(email);
                    newUser.setPassword(password);
                    newUser.setMobile(mobile);

                    userDao.save(newUser);
                    System.out.println("User added successfully with ID: " + newUser.getUid());
                    break;

                case 2:
                    // Logic to find a user by email
                    System.out.print("Enter email: ");
                    String findEmail = scanner.nextLine();
                    User user = userDao.findByEmail(findEmail);
                    if (user != null) {
                        System.out.println("Found User: " + user);
                    } else {
                        System.out.println("User not found!");
                    }
                    break;

                case 3:
                    // Logic to show all users
                    List<User> users = userDao.findAll();
                    if (users.isEmpty()) {
                        System.out.println("No users found.");
                    } else {
                        System.out.println("\nAll Users:");
                        users.forEach(u -> System.out.println(u.getName() + " (" + u.getEmail() + ")"));
                    }
                    break;

                case 4:
                    // Logic to delete a user
                    System.out.print("Enter email to delete: ");
                    String deleteEmail = scanner.nextLine();
                    int rowsAffected = userDao.deleteByEmail(deleteEmail);
                    System.out.println(rowsAffected > 0 ? "User deleted." : "User not found.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void manageFoodItems(Scanner scanner) throws Exception {
        System.out.println("\n--- Food Item Management ---");
        System.out.println("1. Show All Food Items");
        System.out.println("2. Find Food Item by ID");
        System.out.println("3. Add Food Item");
        System.out.println("4. Update Food Price");
        System.out.println("5. Delete Food Item");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             FoodItemDaoImpl foodItemDao = new FoodItemDaoImpl(conn)) {

            switch (choice) {
                case 1:
                    List<FoodItem> items = foodItemDao.findAll();
                    if (items.isEmpty()) {
                        System.out.println("No food items found.");
                    } else {
                        System.out.println("\nAll Food Items:");
                        items.forEach(item -> System.out.printf("%d: %s - $%.2f - %s\n",
                                item.getFid(), item.getName(), item.getPrice(), item.getDescription()));
                    }
                    break;

                case 2:
                    System.out.print("Enter food ID: ");
                    int id = scanner.nextInt();
                    FoodItem item = foodItemDao.findById(id);
                    if (item != null) {
                        System.out.println("Found Item: " + item);
                    } else {
                        System.out.println("Food item not found!");
                    }
                    break;

                case 3:
                    System.out.print("Enter food name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter price: ");
                    double price = scanner.nextDouble();
                    scanner.nextLine();
                    System.out.print("Enter description: ");
                    String description = scanner.nextLine();
                    System.out.print("Enter image filename: ");
                    String image = scanner.nextLine();

                    FoodItem newItem = new FoodItem(name, price, description, image);
                    foodItemDao.save(newItem);
                    System.out.println("Food item added successfully with ID: " + newItem.getFid());
                    break;

                case 4:
                    System.out.print("Enter food ID to update: ");
                    int updateId = scanner.nextInt();
                    System.out.print("Enter new price: ");
                    double newPrice = scanner.nextDouble();
                    int updated = foodItemDao.updatePrice(updateId, newPrice);
                    System.out.println(updated > 0 ? "Price updated successfully." : "Food item not found.");
                    break;

                case 5:
                    System.out.print("Enter food ID to delete: ");
                    int deleteId = scanner.nextInt();
                    int deleted = foodItemDao.deleteById(deleteId);
                    System.out.println(deleted > 0 ? "Food item deleted." : "Food item not found.");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }

    private static void manageOrders(Scanner scanner) throws Exception {
        System.out.println("\n--- Order Management ---");
        System.out.println("1. Place New Order");
        System.out.println("2. View Orders by User");
        System.out.println("3. Update Order Status");
        System.out.println("4. View Order Details");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             OrderDaoImpl orderDao = new OrderDaoImpl(conn);
             UserDaoImpl userDao = new UserDaoImpl(conn);
             FoodItemDaoImpl foodItemDao = new FoodItemDaoImpl(conn)) {

            switch (choice) {
                case 1:
                    // Simplified logic to place an order
                    System.out.print("Enter your User ID to place an order: ");
                    int userId = scanner.nextInt();
                    if (userDao.findById(userId) == null) {
                        System.out.println("User not found!");
                        break;
                    }

                    System.out.print("Enter Food ID to order: ");
                    int foodId = scanner.nextInt();
                    System.out.print("Enter quantity: ");
                    int quantity = scanner.nextInt();

                    FoodItem item = foodItemDao.findById(foodId);
                    if (item == null) {
                        System.out.println("Food item not found!");
                        break;
                    }

                    // Create and save the order
                    Order newOrder = new Order();
                    newOrder.setUid(userId);
                    newOrder.setTotalAmount(item.getPrice() * quantity);
                    newOrder.setStatus("PENDING");
                    int orderId = orderDao.saveOrder(newOrder);

                    // Create and save order detail
                    OrderDetail detail = new OrderDetail();
                    detail.setOid(orderId);
                    detail.setFid(foodId);
                    detail.setQuantity(quantity);
                    orderDao.saveOrderDetail(detail);

                    System.out.println("Order placed successfully with ID: " + orderId);
                    break;

                case 2:
                    // Logic to view orders by user
                    System.out.print("Enter User ID to view orders: ");
                    int uid = scanner.nextInt();
                    List<Order> orders = orderDao.findOrdersByUserId(uid);
                    if (orders.isEmpty()) {
                        System.out.println("No orders found for this user.");
                    } else {
                        System.out.println("\nOrders for User ID " + uid + ":");
                        orders.forEach(o -> System.out.printf("Order ID: %d, Amount: $%.2f, Status: %s, Date: %s\n",
                                o.getOid(), o.getTotalAmount(), o.getStatus(), o.getOrderDate()));
                    }
                    break;

                case 3:
                    // Logic to update order status
                    System.out.print("Enter Order ID to update: ");
                    int oId = scanner.nextInt();
                    scanner.nextLine(); // consume newline
                    System.out.print("Enter new status (PENDING, PROCESSING, DELIVERED, CANCELLED): ");
                    String status = scanner.nextLine().toUpperCase();
                    int updated = orderDao.updateOrderStatus(oId, status);
                    System.out.println(updated > 0 ? "Status updated." : "Order not found.");
                    break;

                case 4:
                    // Logic to view order details
                    System.out.print("Enter Order ID to view details: ");
                    int orderIdToView = scanner.nextInt();
                    Order order = orderDao.findOrderById(orderIdToView);
                    if (order == null) {
                        System.out.println("Order not found!");
                        break;
                    }

                    System.out.println("\nOrder Information:");
                    System.out.println(order);

                    List<OrderDetail> details = orderDao.findOrderDetailsByOrderId(orderIdToView);
                    if (!details.isEmpty()) {
                        System.out.println("\nOrder Details:");
                        for (OrderDetail od : details) {
                            FoodItem foodItem = foodItemDao.findById(od.getFid());
                            System.out.printf("Food: %s, Quantity: %d, Price: $%.2f\n",
                                    foodItem != null ? foodItem.getName() : "Unknown",
                                    od.getQuantity(),
                                    foodItem != null ? foodItem.getPrice() * od.getQuantity() : 0.0);
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid choice.");
            }
        }
    }
}