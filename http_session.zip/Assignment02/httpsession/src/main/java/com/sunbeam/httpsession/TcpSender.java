package com.sunbeam.httpsession;

public class TcpSender implements Sender {
    @Override
    public void send(double value) {
        System.out.println("TcpSender sending value: " + value);
    }
}