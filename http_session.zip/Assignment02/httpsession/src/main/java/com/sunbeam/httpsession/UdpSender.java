package com.sunbeam.httpsession;

public class UdpSender implements Sender {
    @Override
    public void send(double value) {
        System.out.println("UdpSender sending value: " + value);
    }
}