package com.sunbeam.httpsession;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        // Create Spring Application Context
        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

        System.out.println("=== Accessing beans by specific class ===");

        // Access TcpSender bean
        TcpSender ts = ctx.getBean(TcpSender.class);
        ts.send(100.50);

        // Access HttpSender bean
        HttpSender hs = ctx.getBean(HttpSender.class);
        hs.send(200.75);

        // Access UdpSender bean
        UdpSender us = ctx.getBean(UdpSender.class);
        us.send(300.25);

        System.out.println("\n=== Accessing bean by interface (with @Primary) ===");

        // Access Sender bean - works now because @Primary is specified
        Sender sender = ctx.getBean(Sender.class);
        sender.send(999.99);

        // Close the context
        ((AnnotationConfigApplicationContext) ctx).close();
    }
}