package com.sunbeam.httpsession;

public interface Sender {
    void send(double value);
}
