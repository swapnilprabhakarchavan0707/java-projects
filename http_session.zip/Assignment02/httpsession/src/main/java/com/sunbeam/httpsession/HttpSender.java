package com.sunbeam.httpsession;

public class HttpSender implements Sender {
    @Override
    public void send(double value) {
        System.out.println("HttpSender sending value: " + value);
    }
}
