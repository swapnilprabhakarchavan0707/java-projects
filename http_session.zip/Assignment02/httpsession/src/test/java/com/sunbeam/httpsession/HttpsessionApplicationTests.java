package com.sunbeam.httpsession;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HttpsessionApplicationTests {

	@Test
	void contextLoads() {
	}

}
