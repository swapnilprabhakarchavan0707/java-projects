package com.sunbeam.daos;

import com.sunbeam.daos.UserDao;
import com.sunbeam.daos.UserRowMapper;
import com.sunbeam.pojos.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDaoImpl implements UserDao {

    private JdbcTemplate jdbcTemplate;
    private UserRowMapper userRowMapper;

    @Autowired
    public UserDaoImpl(JdbcTemplate jdbcTemplate, UserRowMapper userRowMapper) {
        this.jdbcTemplate = jdbcTemplate;
        this.userRowMapper = userRowMapper;
    }

    @Override
    public List<User> findAll() throws Exception {
        String sql = "SELECT * FROM user";
        List<User> list = jdbcTemplate.query(sql, userRowMapper);
        return list;
    }

    @Override
    public User findById(int id) throws Exception {
        String sql = "SELECT * FROM user WHERE uid=?";
        List<User> list = jdbcTemplate.query(sql, userRowMapper, id);
        return list.isEmpty() ? null : list.get(0);
    }

    @Override
    public int save(User user) throws Exception {
        String sql = "INSERT INTO user(name, email, password, mobile) VALUES(?, ?, ?, ?)";
        int cnt = jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getPassword(), user.getMobile());
        return cnt;
    }

    @Override
    public int update(User user) throws Exception {
        String sql = "UPDATE user SET name=?, email=?, password=?, mobile=? WHERE uid=?";
        int cnt = jdbcTemplate.update(sql, user.getName(), user.getEmail(), user.getPassword(), user.getMobile(), user.getUid());
        return cnt;
    }

    @Override
    public int deleteById(int id) throws Exception {
        String sql = "DELETE FROM user WHERE uid=?";
        int cnt = jdbcTemplate.update(sql, id);
        return cnt;
    }
}