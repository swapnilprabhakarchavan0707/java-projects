package com.sunbeam.controller;

import com.sunbeam.daos.UserDao;
import com.sunbeam.pojos.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/v3")
@RestController
public class UserControllerV3 {

    @Autowired
    private UserDao userDao;

    @GetMapping("/users")
    public ResponseEntity<?> getAllUsers() throws Exception {
        List<User> list = userDao.findAll();
        return ResponseEntity.ok(list);
    }

    @GetMapping("/users/{userId}")
    public ResponseEntity<?> getUserById(@PathVariable("userId") int uid) throws Exception {
        User user = userDao.findById(uid);
        if (user == null) return ResponseEntity.notFound().build();
        return ResponseEntity.ok(user);
    }

    @PostMapping("/users")
    public ResponseEntity<?> addUser(@RequestBody User user) throws Exception {
        int cnt = userDao.save(user);
        return ResponseEntity.created(null).build();
    }

    @PutMapping("/users/{userId}")
    public ResponseEntity<?> updateUser(@PathVariable("userId") int uid, @RequestBody User user) throws Exception {
        user.setUid(uid);
        int cnt = userDao.update(user);
        if (cnt == 0) return ResponseEntity.notFound().build();
        return ResponseEntity.ok("Success");
    }

    @DeleteMapping("/users/{userId}")
    public ResponseEntity<?> deleteUserById(@PathVariable("userId") int uid) throws Exception {
        int cnt = userDao.deleteById(uid);
        if (cnt == 0) return ResponseEntity.notFound().build();
        return ResponseEntity.ok("Success");
    }
}