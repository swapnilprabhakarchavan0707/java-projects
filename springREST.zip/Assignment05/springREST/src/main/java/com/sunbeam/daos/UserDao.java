package com.sunbeam.daos;

import com.sunbeam.pojos.User;
import java.util.List;

public interface UserDao {
    User findById(int id) throws Exception;
    List<User> findAll() throws Exception;
    int save(User user) throws Exception;
    int update(User user) throws Exception;
    int deleteById(int id) throws Exception;
}
