package com.sunbeam.controller;

import com.sunbeam.daos.UserDao;
import com.sunbeam.pojos.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
public class UserControllerV1 {

    @Autowired
    private UserDao userDao;

    @GetMapping("/users")
    public @ResponseBody List<User> getAllUsers() throws Exception {
        List<User> list = userDao.findAll();
        return list;
    }

    @GetMapping("/users/{userId}")
    public @ResponseBody User getUserById(@PathVariable("userId") int uid) throws Exception {
        User user = userDao.findById(uid);
        return user;
    }

    @PostMapping("/users")
    public @ResponseBody String addUser(@RequestBody User user) throws Exception {
        int cnt = userDao.save(user);
        return "Records Saved: " + cnt;
    }

    @PutMapping("/users/{userId}")
    public @ResponseBody String updateUser(@PathVariable("userId") int uid, @RequestBody User user) throws Exception {
        user.setUid(uid);
        int cnt = userDao.update(user);
        return "Records Updated: " + cnt;
    }

    @DeleteMapping("/users/{userId}")
    public @ResponseBody String deleteUserById(@PathVariable("userId") int uid) throws Exception {
        int cnt = userDao.deleteById(uid);
        return "Records Deleted: " + cnt;
    }
}
